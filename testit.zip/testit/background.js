// var successURL = 'http://localhost:3000/fr/members/register';
// alert('pige po');
// console.log('set to null');
// localStorage.accessToken = null;
// alert('setted to null');

// alert(localStorage.accessToken);

// function onFacebookLogin() {

// 	console.log('onFacebookLogin');

// 	if (!localStorage.accessToken) {
// 	    chrome.tabs.getAllInWindow(null, function(tabs) {
// 	        for (var i = 0; i < tabs.length; i++) {

// 	        	alert(tabs[i].url);


// 	            if (tabs[i].url.indexOf(successURL) == 0) {

// 	            	console.log('YES FOR : ' + tabs[i].url);

// 	    //             var params = tabs[i].url.split('#')[1];

// 					// access = params.split('&')[0]
// 	    //             console.log(access);
// 	    //             localStorage.accessToken = access;
// 	    //             chrome.tabs.onUpdated.removeListener(onFacebookLogin);
// 	                return;
// 	            }
// 	        }
// 	    });
// 	}
// }


// chrome.tabs.onUpdated.addListener(onFacebookLogin);
