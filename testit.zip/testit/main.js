
var urlConfirmation = '/members/loggedfb';
var urlLoginFB = '/members/register_charly';

// var urlSite = 'http://localhost:3000/fr';
// var apiUrl = 'http://localhost:3000';
var apiUrl = 'http://www.mercicharly.com';
var urlSite = 'http://www.mercicharly.com/fr';


var now = moment();
var _momentFormat = 'minutes';
var _momentNumber = 1;
var accessToken = null;



function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

var hideCharly = function(){
	$('.charly_tmplate').hide();
}

var setNewTime = function(){
	chrome.storage.sync.set({'lastTime': now.format().toString()}, function() {
		// cb(null, true);
		return;
	});
}

var checkIfUpdateNeeded = function(cb){

	chrome.storage.sync.get('lastTime', function (result) {
		if(!result.lastTime){
			//Set New Date
			chrome.storage.sync.set({'lastTime': now.format().toString()}, function() {
				cb(null, false);
			});
		}
		else{
			console.log(result.lastTime);
			console.log(now.format());
			// console.log(moment(result.lastTime).add(2, 'd').format());

			var diff = now.diff(moment(result.lastTime), _momentFormat);
			console.log(diff);


			if(diff >= _momentNumber){
				cb(null, true);
			}
			else{
				cb(null, false);
			}
		}
	});
}

var validateReward = function(reward){
	$.ajax({
		url: apiUrl + '/api/rewards/validate/'+ reward._id,
		type: 'PUT',
		data: reward,
		success: function(data) {
			hideCharly();
			setNewTime();
		}
	});
}

var displayCharly_notAuth = function(cb){
	$.get(chrome.extension.getURL('/notAuth.html'), function(data) {
		$(data).appendTo('body');

			//set clicks events
		$( "#mc_notif" ).click(function() {
			$( "#mc_cover" ).show();
		});

		$( ".mc_box_cross" ).click(function() {
			$( "#mc_cover" ).hide();
			$( "#mc_notif" ).hide();
		});

		cb();
	});
}

var displayCharly = function(reward, cb){
	$.get(chrome.extension.getURL('/template.html'), function(data) {

		$(data).appendTo('body');


		//set clicks events
		$( "#mc_notif" ).click(function() {
			$( "#mc_cover" ).show();
			updateDisplayedReward(reward);
		});

		$( ".mc_box_cross" ).click(function() {
			$( "#mc_cover" ).hide();
		});

		$('.closeX').click(function(){
			alert('close me');
		})


		$( "#btnGetEmail" ).click(function() {
			validateReward(reward);
		});

		$('#display_charly img').attr("src", reward.pictures[0]);
		cb();
	});
}

var getReward = function(cb){

	console.log(accessToken);
	var jqxhr = $.ajax({
		url: apiUrl  + "/api/rewards/get",
		beforeSend: function( xhr ) {
			xhr.setRequestHeader('Authorization', accessToken);
		}
	})
	.done(function( data ) {
		console.log(data);
		cb(null, data);
	})
	.fail(function() {
		cb('fail', null);
	})
}

var updateDisplayedReward = function(reward){
	$.ajax({
		url: apiUrl + '/api/rewards/displayed/'+ reward._id,
		beforeSend: function( xhr ) {
			xhr.setRequestHeader('Authorization', accessToken);
		},
		type: 'PUT',
		data: reward,
		success: function(data) {
			console.log(data);
		}
	});
}

var checkIfAuth  = function(cb){
	chrome.storage.sync.get('accessToken', function (result) {
		if(!result.accessToken){
			console.log('no token');
			cb('no token', false);
		}
		else{
			accessToken = result.accessToken;
			cb(null, true);
		}
	});
}


var startsAPP = function(){

	console.log('started.');

	// APP START
	checkIfUpdateNeeded(function(err, ok){

		if(!ok){
			console.log('no update needed');
			return;
		}

		console.log('potential reward for you !');

		checkIfAuth(function(err, auth){
			if(!auth){
				setNewTime();
				displayCharly_notAuth(function(){
					console.log('NOT AUTH')
					return;
				});

			}else{

				getReward(function(err, reward){
					if(err){
						console.log(err)
						return;
					}

					if(reward){
						displayCharly(reward, function(){
							console.log('GOT REWARD.');
							setNewTime();
						})
					}else{
						console.log('NO NEW REWARDS FOR YOU RIGHT NOW');
						return;
					}
				});
			}
		})
	})
}


var setupFirstTime = function(cb){
	chrome.storage.sync.get('firstTime', function (result) {

		if(!result.firstTime){
			chrome.storage.sync.set({'firstTime': true}, function() {
				var win = window.open(urlSite + urlLoginFB, '_blank');
	  			win.focus();
			});
		}

	});
}


displayCharly();
setupFirstTime();


//if url
if(window.location.href.indexOf(urlConfirmation) != -1){
	var token = $('#inputtoken').val();
	chrome.storage.sync.set({'accessToken': token}, function() {
		alert('new token setted');
	});
}else if(window.location.href.indexOf(urlLoginFB) != -1){

}else{
	startsAPP();
}



























// $.get( "https://api.tipi.be/api/ads", function( data ) {
// 	console.log(data);
// });

// var token = 'JWT eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyIkX18iOnsic3RyaWN0TW9kZSI6dHJ1ZSwiZ2V0dGVycyI6e30sIndhc1BvcHVsYXRlZCI6ZmFsc2UsImFjdGl2ZVBhdGhzIjp7InBhdGhzIjp7ImFkbWluIjoiaW5pdCIsImFjdGl2YXRlZCI6ImluaXQiLCJzZWNyZXQiOiJpbml0IiwicGljdHVyZSI6ImluaXQiLCJyb2xlcyI6ImRlZmF1bHQiLCJfX3YiOiJpbml0IiwiZW1haWwiOiJpbml0IiwiX2lkIjoiaW5pdCJ9LCJzdGF0ZXMiOnsiaWdub3JlIjp7fSwiZGVmYXVsdCI6eyJyb2xlcyI6dHJ1ZX0sImluaXQiOnsiX192Ijp0cnVlLCJhZG1pbiI6dHJ1ZSwiYWN0aXZhdGVkIjp0cnVlLCJzZWNyZXQiOnRydWUsInBpY3R1cmUiOnRydWUsImVtYWlsIjp0cnVlLCJfaWQiOnRydWV9LCJtb2RpZnkiOnt9LCJyZXF1aXJlIjp7fX0sInN0YXRlTmFtZXMiOlsicmVxdWlyZSIsIm1vZGlmeSIsImluaXQiLCJkZWZhdWx0IiwiaWdub3JlIl19LCJlbWl0dGVyIjp7ImRvbWFpbiI6bnVsbCwiX2V2ZW50cyI6e30sIl9ldmVudHNDb3VudCI6MCwiX21heExpc3RlbmVycyI6MH19LCJpc05ldyI6ZmFsc2UsIl9kb2MiOnsiYWRtaW4iOmZhbHNlLCJhY3RpdmF0ZWQiOmZhbHNlLCJzZWNyZXQiOm51bGwsInBpY3R1cmUiOiJodHRwczovL3Njb250ZW50Lnh4LmZiY2RuLm5ldC9ocHJvZmlsZS14bHQxL3YvdDEuMC0xL3A1MHg1MC8xMDE1NDk3M18xMTQxNzg0MzIyNTIyOTU4XzEyNzI4MDIwMDUyNjc0OTc0NjRfbi5qcGc_b2g9ZDA4MDA3YmYyNDgzMTVmMjU4YTg1OGZiMDFlODJjNmUmb2U9NTc1RDY2ODAiLCJyb2xlcyI6WyJ1c2VyIl0sIl9fdiI6MCwiZW1haWwiOiJwaXJvQGxpdmUuYmUiLCJfaWQiOiI1NmQwNjJkNWI3MWY5NjE2MzcwMWVjYjcifSwiX3ByZXMiOnsiJF9fb3JpZ2luYWxfc2F2ZSI6W251bGwsbnVsbF19LCJfcG9zdHMiOnsiJF9fb3JpZ2luYWxfc2F2ZSI6W119LCJpYXQiOjE0NTc2ODU3MzEsImV4cCI6MTQ1NzY5NTgxMX0.qeEvfBeJb3kkMalB_XeSpEo7rKGXBu3KGP9bvtRJUz4';
// $.ajax({
//   url: "http://localhost:3000/profile",
//   beforeSend: function( xhr ) {
//   	xhr.setRequestHeader('Authorization', token);
//   }
// })
//   .done(function( data ) {
//       console.log( data );
//   });






// var theValue = "Joao ;D 2";

// chrome.storage.sync.set({'value': theValue}, function() {
//   // Notify that we saved.
// });

// chrome.storage.sync.set({'lastTime': theValue}, function() {
//   // Notify that we saved.
// });









// var audio = new Audio("bip.mp3");
// audio.play();                   // play the music

// var audioElement = document.createElement('audio');
// audioElement.setAttribute('src', '/bip.mp3');
// audioElement.setAttribute('autoplay', 'autoplay');
// //audioElement.load()

// $.get();

// audioElement.addEventListener("load", function() {
//     audioElement.play();
// }, true);

// $('.play').click(function() {
//     audioElement.play();
// });

// $('.pause').click(function() {
//     audioElement.pause();
// });
