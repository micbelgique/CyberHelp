================	================	================	================
=	scenario   =	=	scenario   =	=	scenario   =	=	scenario   =
================	================	================	================


FirstTime
---------
	-> New Page + ASK Login (fb)
	-> Save AccessToken
			???? Quid if user does not Register/Login?

Usual
-----
	-> Check if Potential Reward
	°°	false
			- Do Nothing

	°°	true
			- Check AccessToken
				°°	false (notValid)
						???????

				°°	true (valid)
					- Get Reward (except already recieved)
					- Set New Time : 0
					- Display Charly (ᚖᚖᚖ)


(ᚖᚖᚖ) User Clicks on Charly
--------------------------
	-> Display Reward
	-> Save Reward Id To avoid duplicates rewards
			??? User is asked to click on a button to received Reward ?



(ᚖᚖᚖ) User Doenst Click on Charly or close it
--------------------------------------------
	-> Do nothing


